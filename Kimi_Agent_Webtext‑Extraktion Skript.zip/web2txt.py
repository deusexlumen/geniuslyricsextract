#!/usr/bin/env python3
"""
web2txt.py - Extrahiert Plain Text von Webseiten in .txt-Dateien.

Mit Genius.com-Support und intelligenter Dateierkennung.
"""

import argparse
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup


def sanitize_filename(name: str, max_len: int = 80) -> str:
    name = re.sub(r'[^\w\-]', '_', name).strip('_')
    return name[:max_len] + ".txt"


def is_html_bookmark_file(content: str) -> bool:
    """Prüft ob der Inhalt eine HTML-Bookmark-Datei ist."""
    stripped = content.strip().lower()
    return (stripped.startswith("<!doctype") or 
            stripped.startswith("<html") or 
            "<!doctype netscape-bookmark-file-1" in stripped or
            ("<title" in stripped and "<dl>" in stripped))


def extract_genius_lyrics(soup: BeautifulSoup) -> str | None:
    """Extrahiert Lyrics von Genius.com-Seiten."""
    containers = soup.select('[data-lyrics-container="true"]')
    if containers:
        lyrics_parts = []
        for container in containers:
            for br in container.find_all("br"):
                br.replace_with("\n")
            lyrics_parts.append(container.get_text())
        return "\n".join(lyrics_parts).strip()
    
    lyric_div = soup.select_one('.lyrics, .Lyrics__Container-sc-1ynbvzw-1, [class*="Lyrics__Container"]')
    if lyric_div:
        for br in lyric_div.find_all("br"):
            br.replace_with("\n")
        return lyric_div.get_text().strip()
    
    script_tags = soup.find_all("script", type="application/ld+json")
    for script in script_tags:
        try:
            import json
            data = json.loads(script.string)
            if isinstance(data, dict) and "articleBody" in data:
                return data["articleBody"].strip()
        except (json.JSONDecodeError, AttributeError):
            continue
    
    return None


def extract_text(url: str, timeout: int = 15) -> tuple[str, str]:
    """Holt die Seite und extrahiert Text. Gibt (text, source_type) zurück."""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/125.0.0.0 Safari/537.36",
        "Accept-Language": "de-DE,de;q=0.9,en;q=0.8"
    }
    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "html.parser")
    is_genius = "genius.com" in urlparse(url).netloc.lower()
    
    if is_genius:
        lyrics = extract_genius_lyrics(soup)
        if lyrics:
            title_tag = soup.find("title")
            header = ""
            if title_tag:
                title_text = title_tag.get_text()
                header = title_text.split("|")[0].strip() + "\n" + "=" * 40 + "\n\n"
            return header + lyrics, "genius"
    
    for tag in soup(["script", "style", "noscript", "header", "footer",
                     "nav", "aside", "form", "iframe", "svg", "button"]):
        tag.decompose()

    text = soup.get_text(separator="\n")
    lines = [line.strip() for line in text.splitlines()]
    lines = [line for line in lines if line]

    return "\n".join(lines), "generic"


def parse_bookmarks(content: str) -> list[tuple[str, str]]:
    """Parst HTML-Bookmark-Inhalt."""
    soup = BeautifulSoup(content, "html.parser")
    links = []
    for dt in soup.find_all("dt"):
        a = dt.find("a")
        if a and a.get("href"):
            url = a["href"]
            title = a.get_text(strip=True)
            if url.startswith(("http://", "https://")):
                links.append((url, title))
    return links


def parse_batch_file(content: str) -> list[str]:
    """Liest URLs aus Textinhalt (eine pro Zeile)."""
    lines = content.splitlines()
    return [line.strip() for line in lines 
            if line.strip() and not line.startswith("#")]


def save_text(text: str, filepath: Path) -> None:
    filepath.parent.mkdir(parents=True, exist_ok=True)
    filepath.write_text(text, encoding="utf-8")


def load_tasks(filepath: Path) -> list[tuple[str, str | None]]:
    """Erkennt Dateityp anhand des Inhalts und gibt (url, title)-Liste zurück."""
    content = filepath.read_text(encoding="utf-8", errors="ignore")
    
    if is_html_bookmark_file(content):
        print(f"  Erkannt als HTML-Bookmarks")
        return parse_bookmarks(content)
    else:
        print(f"  Erkannt als URL-Liste (Text)")
        return [(url, None) for url in parse_batch_file(content)]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Webseiten → Plain Text (.txt) mit Genius-Support",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Beispiele:
  python web2txt.py https://genius.com/Genetikk-supa-dope-brothers-lyrics
  python web2txt.py bookmarks.html --dir lyrics/
  python web2txt.py --batch urls.txt --dir output/
        """
    )
    parser.add_argument("input", nargs="+", 
                       help="URLs, Batch-Dateien (.txt) oder Bookmark-Dateien (.html)")
    parser.add_argument("--output", "-o", metavar="DATEI", 
                       help="Zieldatei (nur bei einer URL sinnvoll)")
    parser.add_argument("--dir", "-d", default=".", 
                       help="Zielverzeichnis")
    parser.add_argument("--prefix", "-p", default="", 
                       help="Präfix für Dateinamen")
    parser.add_argument("--raw", action="store_true",
                       help="Kein Genius-Filter, immer generische Extraktion")
    args = parser.parse_args()

    target_dir = Path(args.dir)
    tasks: list[tuple[str, str | None]] = []
    
    for item in args.input:
        p = Path(item)
        
        if p.exists():
            print(f"Lade: {p}")
            tasks.extend(load_tasks(p))
        elif item.startswith(("http://", "https://")):
            tasks.append((item, None))
        else:
            print(f"Warnung: Überspringe '{item}'", file=sys.stderr)

    if not tasks:
        print("Keine URLs gefunden.", file=sys.stderr)
        sys.exit(1)

    print(f"\n{len(tasks)} URLs gefunden. Starte Download...\n")
    
    ok, failed, genius_count = 0, 0, 0

    for url, title in tasks:
        try:
            if args.raw:
                headers = {"User-Agent": "Mozilla/5.0"}
                resp = requests.get(url, headers=headers, timeout=15)
                soup = BeautifulSoup(resp.text, "html.parser")
                for tag in soup(["script", "style", "noscript", "header", "footer",
                                 "nav", "aside", "form", "iframe", "svg", "button"]):
                    tag.decompose()
                text = "\n".join([l.strip() for l in soup.get_text(separator="\n").splitlines() if l.strip()])
                source_type = "generic"
            else:
                text, source_type = extract_text(url)
            
            if source_type == "genius":
                genius_count += 1
            
            if title:
                base_name = sanitize_filename(title)
            else:
                parsed = urlparse(url)
                base_name = sanitize_filename(parsed.netloc + parsed.path)
            
            if args.prefix:
                base_name = sanitize_filename(args.prefix) + "_" + base_name
            
            out = target_dir / base_name
            
            counter = 1
            original_out = out
            while out.exists():
                out = original_out.with_stem(f"{original_out.stem}_{counter}")
                counter += 1
            
            save_text(text, out)
            
            marker = "🎵" if source_type == "genius" else "📝"
            print(f"{marker} {title or url}  →  {out.name}  ({len(text)} Zeichen)")
            ok += 1
            
        except Exception as e:
            print(f"✗ {url}  →  FEHLER: {e}", file=sys.stderr)
            failed += 1

    print(f"\nFertig: {ok} erfolgreich ({genius_count} Genius-Lyrics), {failed} fehlgeschlagen.")


if __name__ == "__main__":
    main()
